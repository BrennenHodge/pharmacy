import ClientHome from "./ClientHome"

export const metadata = {
  title: "Home | VOXO Pharmacy",
  description: "Welcome to VOXO Pharmacy communication system",
}

export default function Home() {
  return <ClientHome />
}

